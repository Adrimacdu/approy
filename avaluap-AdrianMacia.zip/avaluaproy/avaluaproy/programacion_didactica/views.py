from django.shortcuts import render

# Create your views here.

from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from programacion_didactica.models import Unidad, InstEvaluacion, PondRA, PondCriterio, PondCritUD
from django.urls import reverse_lazy
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.http import request
from core.mixins import coreMixin , deleteMixin
from programacion_didactica.forms import UnidadForm, InstEvaluacionForm, PondRAForm, PondCriterioForm, PondCritUDForm

# UD6.7.a

class UnidadListView(ListView):
    model = Unidad
    template_name = 'programacion_didactica/unidad_list.html'

    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset

class UnidadDetailView(DetailView):
    model = Unidad
    template_name = 'programacion_didactica/unidad_detail.html'

class InstEvListView(ListView):
    model = InstEvaluacion
    template_name = 'programacion_didactica/ie_list.html'

    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset

class InstEvDetailView(DetailView):
    model = InstEvaluacion
    template_name = 'programacion_didactica/ie_detail.html'

class PondRAListView(ListView):
    model = PondRA
    template_name = 'programacion_didactica/pond_ra_list.html'

    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset

class PondRADetailView(DetailView):
    model = PondRA
    template_name = 'programacion_didactica/pond_ra_detail.html'

class PondCritListView(ListView):
    model = PondCriterio
    template_name = 'programacion_didactica/pond_ce_list.html' 

    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset

class PondCritDetailView(DetailView):
    model = PondCriterio
    template_name = 'programacion_didactica/pond_ce_detail.html'

class PondCritUDListView(ListView):
    model = PondCritUD
    template_name = 'programacion_didactica/pond_ce_ud_list.html'

    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset


    #UD7.2.j
    def get_queryset(self):
        orden = self.request.GET.get('orden', None)
        queryset = Modulo.objects.all()
        if orden:
            if orden == 'asc':
                queryset = queryset.order_by('id')
            elif orden == 'desc':
                queryset = queryset.order_by('-id')

        return queryset


class PondCritUDDetailView(DetailView):
    model = PondCritUD
    template_name = 'programacion_didactica/pond_ce_ud_detail.html'


#UD7.2.a

class UDCreateView(coreMixin, CreateView):
    model= Unidad
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ud_create')
    #UD7.2.c
    titulo_actualizacion = ''
    titulo_creacion = 'crear una unidad'
    url_borrado = 'unidad_delete'    

    form_class = UnidadForm

#UD7.2.a
class UDUpdateView(coreMixin, UpdateView):
    model = Unidad
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ud_update')
    #UD7.2.c
    titulo_actualizacion = 'actualizar una unidad'
    titulo_creacion = ''
    url_borrado = 'unidad_delete'

    form_class = UnidadForm

#UD7.2.a
class UDDeleteView(deleteMixin, DeleteView):
    model = Unidad
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('ud_list')
    #UD7.2.f
    titulo = 'Unidad'
    mensaje_confirmacion = '¿Estas seguro de que quieres borrar la unidad?'
    
    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {object.str}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))

#UD7.2.a
class InstEvaluacionCreateView(coreMixin, CreateView):
    model= InstEvaluacion
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ie_create')
    #UD7.2.c
    titulo_actualizacion = ''
    titulo_creacion = 'crear un instrumento de evaluacion'
    url_borrado = 'ie_delete'

    form_class = InstEvaluacionForm

#UD7.2.a
class InstEvaluacionUpdateView(coreMixin, UpdateView):
    model = InstEvaluacion
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('ie_update')
    #UD7.2.c
    titulo_actualizacion = 'actualizar un instrumento evaluacion'
    titulo_creacion = ''
    url_borrado = 'ie_delete'

    form_class = InstEvaluacionForm

#UD7.2.a
class InstEvaluacionDeleteView(deleteMixin, DeleteView):
    model = InstEvaluacion
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('ie_list')
    #UD7.2.f
    titulo = 'Instrumento de evaluación'
    mensaje_confirmacion = '¿Estas seguro de que quieres borrar el instrumento de evaluacion?'
    
    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {object.str}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
    
#UD7.2.a
class PonderacionRACreateView(coreMixin, CreateView):
    model= PondRA
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ra_create')
    #UD7.2.c
    titulo_actualizacion = ''
    titulo_creacion = 'crear un resultado de aprendizaje'
    url_borrado = 'pond_ra_delete'

    form_class = PondRAForm

#UD7.2.a
class PonderacionRAUpdateView(coreMixin, UpdateView):
    model = PondRA
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ra_update')
    #UD7.2.c
    titulo_actualizacion = 'ctualizar un resultado de aprendizaje'
    titulo_creacion = ''
    url_borrado = 'pond_ra_delete'

    form_class = PondRAForm

#UD7.2.a
class PonderacionRADeleteView(deleteMixin, DeleteView):
    model = PondRA
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ra_list')
    #UD7.2.f
    titulo = 'Ponderación de resultado de aprendizaje'
    mensaje_confirmacion = '¿Estas seguro de que quieres borrar la ponderacion del resultado de aprendizaje?'
    
    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {object.str}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
    
#UD7.2.a
class PondCriterioCreateView(coreMixin, CreateView):
    model= PondCriterio
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ce_create')
    #UD7.2.c
    titulo_actualizacion = ''
    titulo_creacion = 'crear una ponderacion de un criterio de evaluacion'
    url_borrado = 'pond_ce_delete'

    form_class = PondCriterioForm

#UD7.2.a
class PondCriterioUpdateView(coreMixin, UpdateView):
    model = PondCriterio
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ce_update')
    #UD7.2.c
    titulo_actualizacion = 'actualizar una ponderacion de un criterio de evaluacion'
    titulo_creacion = ''
    url_borrado = 'pond_ce_delete'

    form_class = PondCriterioForm

#UD7.2.a
class PondCriterioDeleteView(deleteMixin, DeleteView):
    model = PondCriterio
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ce_list')
    #UD7.2.f
    titulo = 'Ponderación de critério de evaluación'
    mensaje_confirmacion = '¿Estas seguro de que quieres borrar la ponderacion del criterio de evaluacion?'
    
    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {object.str}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a
class PondCriterioUDCreateView(coreMixin, CreateView):
    model= PondCritUD
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ce_ud_create')
    #UD7.2.c
    titulo_actualizacion = ''
    titulo_creacion = 'crear una ponderacion de un criterio de evaluacion por unidad'
    url_borrado = 'pond_ce_ud_delete'

    form_class = PondCritUDForm


#UD7.2.a
class PondCriterioUDUpdateView(coreMixin, UpdateView):
    model = PondCritUD
    template_name = 'common/base_create_update.html'
    success_url = reverse_lazy('pond_ce_ud_update')
    #UD7.2.c
    titulo_actualizacion = 'actualizar una ponderacion de un criterio de evaluacion por unidad'
    titulo_creacion = ''
    url_borrado = 'pond_ce_ud_delete'

    form_class = PondCritUDForm


#UD7.2.a
class PondCriterioUDDeleteView(deleteMixin, DeleteView):
    model = PondCritUD
    template_name = 'common/base_confirm_delete.html'
    success_url = reverse_lazy('pond_ce_ud_list')
    #UD7.2.f
    titulo = 'Ponderación de critério de evaluación por unidad'
    mensaje_confirmacion = '¿Estas seguro de que quieres borrar la ponderacion del criterio de evaluacion por unidad?'
    
    def delete(self, request, *args, **kwargs):
        try:
            super().delete(*args, **kwargs)
        except:
            messages.error(self.request, "Existen dependencias para el objeto {object.str}. Elimine antes dichas dependencias".format())
            return HttpResponseRedirect(reverse('home'))
        
#UD7.2.a