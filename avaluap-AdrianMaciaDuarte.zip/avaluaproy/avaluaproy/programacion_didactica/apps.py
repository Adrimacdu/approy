from django.apps import AppConfig


class ProgramacionDidacticaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    # UD6.4.d
    name = 'programacion_didactica'
    verbose_name = 'programacion_didactica'
