from django.db import models
#UD8.1.b
from django.contrib.auth.base_user import AbstractBaseUser

# Create your models here.

#UD8.1.b
class MyUser(AbstractBaseUser, models.Model):
    username = models.CharField(max_length=30, null=True)
    email = models.EmailField(max_length=40, unique=True)
    activo = models.BooleanField()
    create_date = models.DateField(auto_now_add=True)
    update_date = models.DateField(auto_now=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    USERNAME_FIELD = 'email'