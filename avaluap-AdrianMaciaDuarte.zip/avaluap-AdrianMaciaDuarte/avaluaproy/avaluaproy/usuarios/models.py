from django.db import models
#UD8.1.b
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager

# Create your models here.

#UD8.1.b
class MyUserManager(BaseUserManager):
    
    def create_user(
        self, email, first_name=None, last_name=None, password=None, type=None
    ):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError("Ha de proporcionar un e-mail válido")
        user = self.model(
            email=self.normalize_email(email),
            first_name=first_name,
            last_name=last_name,
        )

        user.is_active = False
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email, password):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError("Ha de proporcionar un e-mail válido")
        
        user = self.model(email=self.normalize_email(email))
        
        user.set_password(password)
        user.is_staff = True
        user.is_active = True
        user.is_superuser = True
        user.save(using=self._db)
        return user


class MyUser(AbstractBaseUser, models.Model):
    #username = models.CharField(max_length=30, null=True)
    username = None
    email = models.EmailField(max_length=40, unique=True)
    activo = models.BooleanField()
    create_date = models.DateField(auto_now_add=True)
    update_date = models.DateField(auto_now=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    
    USERNAME_FIELD = 'email'

    objects = MyUserManager()
